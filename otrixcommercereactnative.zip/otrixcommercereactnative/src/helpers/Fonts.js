const Fonts = {
    Font_Reguler: 'Roboto-Regular',
    Font_Semibold: 'Roboto-Medium',
    Font_Bold: 'Roboto-Bold',
}
export default Fonts;