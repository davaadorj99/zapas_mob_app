//Set your texts and translations here


//Set State is must to rerender UI for the change layout redux can also be used similarly
export function changeLanguage(lang) {

};
[]
export function getLanguage() {

};
