
import * as user from './user';
module.exports = {
    ...user
}
